<?php


echo '

<div class="hd">
<br><br>
<table width="100%">
<td><image src="images/logo.png" width="150" /></td>


<td align="right"><a href="search"><image src="images/search.png" width="40" /></a></td>

</table>
</div>';



?>