
<?php


$con = mysqli_connect("fdb1034.awardspace.net", "4428688_crock", "rapheally1", "4428688_crock", 3306);
if($con){
	
}
else{
	echo 'fail to connect';
}


?>


<link rel="apple-touch-icon" sizes="180x180" href="https://crock.com.ng/images/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://crock.com.ng/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://crock.com.ng/images/favicon-16x16.png">
<link rel="manifest" href="https://crock.com.ng/site.webmanifest">