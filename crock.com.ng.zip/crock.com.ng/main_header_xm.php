<?php

echo '

<div class="hd">
<br>
<center>
<image src="../images/logo.png" width="200" />
</center>
</div>
<br>
<button class="btn-back" onclick="window.history.go(-1)"><b>Back</b></button><br>
<br>';



?>