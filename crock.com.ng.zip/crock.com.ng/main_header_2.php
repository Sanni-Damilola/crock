<?php


echo '

<div class="hdx">
<table width="100%">



<td><image src="../images/logo.png" width="170" /></td>


<td align="right"><a href="../search"><image src="../images/search.png" width="40" /></a></td>



<tr></tr>


</table>

</div>
<br>
<button class="btn-back" onclick="window.history.go(-1)"><b>Back</b></button><br><br>';


?>